/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package triangle;

/**
 *
 * @author cistudent
 */
public class TriangleTest {
    
    public static void main(String[] args) {
        // TODO code application logic here
        
        Triangle tri = new Triangle(3,4,5);
     
     if(assertTrue(myAlarm.setTime(7,30)))
     {
         System.out.println("True");
     }
     
     if(assertEquals(7, myAlarm.getHour()))
     {
         System.out.println("True");
     }
     
     if(assertEquals(30, myAlarm.getMinute()))
     {
         System.out.println("True");
     }
     
     System.out.println("\nMy time = " + myAlarm.getHour() + myAlarm.getMinute());
    }
    }

    public static boolean assertTrue( boolean time)
    {
        return time;
    }
    
    public static boolean assertEquals(int t, int time)
    {
        if(t == time)
            return true;
        else 
            return false;
    }
    
}
